---
name: resume-jd-matcher
description: >
  简历-JD智能匹配分析系统。当用户提供简历和岗位描述(JD)，
  需要做匹配度打分、人岗差异分析、生成Boss直聘打招呼语、
  或根据JD定向改写简历项目经历时，应使用此Skill。
  触发关键词：简历匹配、JD分析、岗位匹配度、简历打分、
  简历优化、简历改写、打招呼语、投递建议、人岗匹配。
---

# 简历-JD智能匹配分析系统 (Resume-JD Matcher)

## 概述

这是一个完整的 6+1 步简历与岗位描述(JD)智能匹配分析系统，提供：
- 简历和JD的自动化解析（PDF/Word/图片/纯文本）
- 基于固定权重的百分制打分（硬性资质40分｜工作经历35分｜项目经验20分｜综合素养5分）
- 三段式结构化分析报告（亮点/风险/建议）
- Boss直聘风格打招呼语生成
- JD定向简历项目经历改写（双版本：精简版+完整版）

## 触发条件

当用户提出以下意图时，触发此 Skill：
- 提供简历和JD，要求分析匹配度
- 询问"我和这个岗位匹配吗"
- 需要简历打分或人岗匹配分析
- 需要生成投递打招呼语
- 需要根据JD优化/改写简历项目经历
- 需要投递建议

## 工作流程

系统按以下步骤顺序执行：

### Step 1: 输入识别与解析
- 使用 `scripts/input_parser.py` 解析简历和JD
- 支持格式：PDF、Word(.docx)、图片(.png/.jpg)、纯文本(.txt/.md)
- PDF 使用 PyPDF2/pdfplumber 提取文本
- Word 使用 python-docx 提取文本
- 图片使用 pytesseract OCR 提取文本

### Step 2: 信息抽取
- 使用 `scripts/info_extractor.py` 抽取结构化信息
- 简历抽取：基本信息、教育经历、工作经历、项目经历、技能证书
- JD抽取：过滤福利套话、提取硬性要求、关键词提取
- JD过滤关键词和技能关键词库见 `references/config.md`

### Step 3: 百分制打分
- 使用 `scripts/scoring_engine.py` 进行四维度打分
- 权重固定不可修改：硬性资质40分｜工作经历35分｜项目经验20分｜综合素养5分
- 区分人群：应届生、社招、转行求职者差异化评分
- 匹配等级：高度匹配(90-100)、中度匹配(75-89)、基本匹配(60-74)、低匹配(0-59)

### Step 4-6: 格式化输出
- 使用 `scripts/output_formatter.py` 生成结构化报告
- 输出模板见 `references/output_template.md`
- 包含：匹配度总览、各维度得分、核心亮点、待提升点、打招呼语、投递建议

### Step 7: JD定向简历改写（按需触发）
- 使用 `scripts/resume_rewriter.py` 进行项目经历改写
- 改写原则：真实底线（不虚构）、JD优先、量化升级、结构统一
- 输出双版本：精简版（招聘平台在线简历）+ 完整版（Word正式简历）
- 附带改写对标说明，标注每处修改与JD的对应关系

## 使用方式

### 快速运行
```bash
# 交互式模式
python scripts/main.py

# 文件模式
python scripts/main.py -r resume.pdf -j jd.txt

# 文件+改写模式
python scripts/main.py -r resume.pdf -j jd.txt --rewrite

# 保存结果
python scripts/main.py -r resume.pdf -j jd.txt --rewrite --save
```

### 编程调用
```python
from scripts.main import ResumeJDMatcher

matcher = ResumeJDMatcher()
result = matcher.run(resume_text, jd_text, do_rewrite=True)
print(result)
```

## 注意事项

1. **Windows编码问题**：main.py 已处理 GBK 编码，自动切换为 UTF-8 输出
2. **依赖安装**：首次使用需安装依赖 `pip install -r scripts/requirements.txt`
3. **PDF解析**：如 PyPDF2 提取失败，会自动回退到 pdfplumber
4. **jieba分词**：首次运行会自动下载分词模型缓存
5. **打分数值**：所有分数为0-100整数，总分等于各维度得分之和
6. **简历改写**：严格遵循不虚构原则，所有数据来源于原始简历
