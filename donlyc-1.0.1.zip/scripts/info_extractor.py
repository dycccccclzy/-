"""
Step 2: 信息抽取模块
从简历和JD中抽取结构化信息
"""

import re
import os
from typing import Dict, List, Any

# 兼容直接运行和包导入
try:
    from .config import JD_FILTER_KEYWORDS, JD_HARD_KEYWORDS, SKILL_KEYWORDS
except ImportError:
    from config import JD_FILTER_KEYWORDS, JD_HARD_KEYWORDS, SKILL_KEYWORDS


class InfoExtractor:
    """简历和JD信息抽取器"""

    # ==================== 简历信息抽取 ====================

    @staticmethod
    def extract_resume(resume_text: str) -> Dict[str, Any]:
        """
        从简历文本中抽取结构化信息
        返回:
        {
            "basic_info": {...},       # 基础信息
            "work_experience": [...],  # 工作经历
            "project_experience": [...], # 项目经验
            "skills_certs": {...},     # 技能证书
            "education": {...},        # 教育背景
            "raw_text": "..."          # 原始文本
        }
        """
        result = {
            "basic_info": InfoExtractor._extract_basic_info(resume_text),
            "work_experience": InfoExtractor._extract_work_experience(resume_text),
            "project_experience": InfoExtractor._extract_project_experience(resume_text),
            "skills_certs": InfoExtractor._extract_skills_certs(resume_text),
            "education": InfoExtractor._extract_education(resume_text),
            "raw_text": resume_text,
            "is_fresher": False,      # 是否为应届生
            "is_career_changer": False, # 是否为转行
        }

        # 判断人群类型
        result["is_fresher"] = InfoExtractor._detect_fresher(result)
        result["is_career_changer"] = InfoExtractor._detect_career_changer(result)

        return result

    @staticmethod
    def _extract_basic_info(text: str) -> Dict[str, str]:
        """抽取基础信息：姓名、年龄、工作年限等"""
        info = {}
        # 姓名（常见模式：中文名2-4字）
        name_match = re.search(r'(?:姓名|名字)[:：\s]*([^\s,，。]{2,4})', text)
        if not name_match:
            # 尝试匹配开头的姓名
            name_match = re.match(r'^([^\s,，。]{2,4})\s', text)
        if name_match:
            info["name"] = name_match.group(1)

        # 工作年限
        year_match = re.search(r'(\d+)[年\s]*[工经][作验][年限历]', text)
        if year_match:
            info["work_years"] = year_match.group(1) + "年"
        else:
            # 尝试从时间推算
            years = re.findall(r'(20\d{2})[\.年/-]', text)
            if len(years) >= 2:
                try:
                    span = max(int(y) for y in years) - min(int(y) for y in years)
                    if 0 < span < 40:
                        info["work_years"] = f"约{span}年"
                except ValueError:
                    pass

        # 邮箱
        email_match = re.search(r'[\w.+-]+@[\w-]+\.[\w.-]+', text)
        if email_match:
            info["email"] = email_match.group(0)

        # 手机号
        phone_match = re.search(r'1[3-9]\d{9}', text)
        if phone_match:
            info["phone"] = phone_match.group(0)

        return info

    @staticmethod
    def _extract_work_experience(text: str) -> List[Dict[str, str]]:
        """抽取工作经历"""
        experiences = []

        # 尝试匹配工作经历段落
        work_section = InfoExtractor._find_section(text, ["工作经历", "工作经验", "工作履历", "职业经历"])

        if work_section:
            # 按公司拆分
            companies = re.split(r'(?:[>\s]*)(?:公司|企业)[:：]?\s*', work_section)
            for part in companies:
                if len(part.strip()) < 10:
                    continue

                exp = {}
                # 公司名
                company_match = re.search(r'([^\s,，。]{2,20}(?:公司|集团|科技|网络|信息|技术|有限公司))', part)
                if company_match:
                    exp["company"] = company_match.group(1)

                # 职位
                position_match = re.search(r'(?:职位|岗位|担任)[:：]?\s*([^\s,，。]+)', part)
                if not position_match:
                    position_match = re.search(r'([^\s,，。]{2,10}(?:工程师|经理|主管|专员|总监|开发|设计|运营|产品))', part)
                if position_match:
                    exp["position"] = position_match.group(1)

                # 时间
                time_match = re.search(r'(20\d{2}[\.年/-]\d{1,2})\s*[-至到~]\s*(20\d{2}[\.年/-]\d{1,2}|至今|现在)', part)
                if time_match:
                    exp["duration"] = time_match.group(0)

                # 工作内容
                exp["description"] = part.strip()

                if exp:
                    experiences.append(exp)

        return experiences

    @staticmethod
    def _extract_project_experience(text: str) -> List[Dict[str, str]]:
        """抽取项目经验"""
        projects = []

        project_section = InfoExtractor._find_section(
            text, ["项目经验", "项目经历", "项目", "主要项目", "重点项目"]
        )

        if project_section:
            # 按项目拆分（常见分隔模式）
            project_parts = re.split(
                r'\n(?=(?:项目[名称]?|Project)[:：]|\d+[\.、）\)])', project_section
            )
            if len(project_parts) <= 1:
                project_parts = re.split(r'\n(?=[A-Z][a-z]+.*?[：:])', project_section)

            for part in project_parts:
                if len(part.strip()) < 15:
                    continue

                proj = {}
                # 项目名称
                name_match = re.search(r'(?:项目[名称]?[:：]?\s*)([^\n]+)', part)
                if name_match:
                    proj["name"] = name_match.group(1).strip()

                # 时间
                time_match = re.search(r'(?:时间|周期)[:：]?\s*([^\n]+)', part)
                if time_match:
                    proj["duration"] = time_match.group(1).strip()

                # 角色
                role_match = re.search(r'(?:角色|职责|负责)[:：]?\s*([^\n]+)', part)
                if role_match:
                    proj["role"] = role_match.group(1).strip()

                # 描述
                proj["description"] = part.strip()

                # 技术栈
                techs = []
                for category, keywords in SKILL_KEYWORDS.items():
                    for kw in keywords:
                        if kw.lower() in part.lower():
                            techs.append(kw)
                proj["tech_stack"] = list(set(techs))

                projects.append(proj)

        return projects

    @staticmethod
    def _extract_skills_certs(text: str) -> Dict[str, List[str]]:
        """抽取技能和证书"""
        skills_section = InfoExtractor._find_section(
            text, ["技能", "专业技能", "技术栈", "证书", "资质", "语言能力"]
        )

        skills = {"technical": [], "languages": [], "certificates": []}

        # 全文中扫描技能关键词
        full_lower = text.lower()
        for category, keywords in SKILL_KEYWORDS.items():
            for kw in keywords:
                if kw.lower() in full_lower:
                    skills["technical"].append(kw)

        # 语言能力
        lang_match = re.findall(r'(英语|日语|韩语|法语|德语)[\s\w]*?(?:四级|六级|N\d|BEC|雅思|托福|TOEFL|IELTS)', text)
        skills["languages"] = list(set(lang_match))

        # 证书
        cert_patterns = [
            r'PMP', r'CFA', r'CPA', r'ACCA', r'软考', r'信息系统项目管理师',
            r'AWS.*?认证', r'CKA', r'CKAD', r'RHCE', r'CCIE', r'OCP',
            r'证券从业', r'基金从业', r'教师资格',
        ]
        for pattern in cert_patterns:
            matches = re.findall(pattern, text, re.IGNORECASE)
            skills["certificates"].extend(matches)

        return skills

    @staticmethod
    def _extract_education(text: str) -> Dict[str, str]:
        """抽取教育背景"""
        edu = {}

        # 学历
        degree_match = re.search(r'(博士|硕士|本科|大专|MBA|EMBA)', text)
        if degree_match:
            edu["degree"] = degree_match.group(1)

        # 学校
        school_match = re.search(r'([^\s,，。]{3,20}(?:大学|学院|School|University))', text)
        if school_match:
            edu["school"] = school_match.group(1)

        # 专业
        major_match = re.search(r'(?:专业|主修)[:：]?\s*([^\s,，。]{2,20})', text)
        if major_match:
            edu["major"] = major_match.group(1)

        return edu

    @staticmethod
    def _find_section(text: str, keywords: List[str]) -> str:
        """从文本中定位指定关键词对应的段落"""
        lines = text.split("\n")
        start_idx = -1
        for i, line in enumerate(lines):
            for kw in keywords:
                if kw in line:
                    start_idx = i
                    break
            if start_idx >= 0:
                break

        if start_idx < 0:
            return ""

        # 取该段及之后内容，直到遇到下一个明显的标题行
        end_idx = len(lines)
        for i in range(start_idx + 1, len(lines)):
            line = lines[i].strip()
            # 检测是否为新的段落标题
            if (len(line) < 30 and (
                re.match(r'^[一二三四五六七八九十]、', line) or
                re.match(r'^\d+[\.、]', line) or
                line.endswith("：") or line.endswith(":") or
                re.match(r'^(教育|技能|项目|工作|实习|证书|自我|联系|个人)', line)
            )):
                end_idx = i
                break

        return "\n".join(lines[start_idx:end_idx])

    @staticmethod
    def _detect_fresher(resume: Dict) -> bool:
        """检测是否为应届生"""
        work_exp = resume.get("work_experience", [])
        if not work_exp:
            return True
        # 工作经历少于1年或只有实习
        for exp in work_exp:
            desc = exp.get("description", "")
            if any(kw in desc for kw in ["实习", "应届", "毕业", "校园"]):
                return True
        return False

    @staticmethod
    def _detect_career_changer(resume: Dict) -> bool:
        """检测是否为转行求职者"""
        # 简单判断：工作经历中的职位跨度大
        work_exp = resume.get("work_experience", [])
        if len(work_exp) >= 2:
            positions = [e.get("position", "") for e in work_exp if e.get("position")]
            if len(set(positions)) >= 2:
                return True
        return False

    # ==================== JD信息抽取 ====================

    @staticmethod
    def extract_jd(jd_text: str) -> Dict[str, Any]:
        """
        从JD文本中抽取结构化要求
        返回:
        {
            "hard_requirements": [...],    # 硬性要求
            "soft_requirements": [...],    # 软性要求
            "position": "",               # 岗位名称
            "keywords": [...],             # 核心关键词
            "raw_text": "",               # 原始JD
            "filtered_text": "",          # 过滤福利套话后的JD
            "is_brief": False,            # JD是否过于简短
        }
        """
        result = {
            "hard_requirements": [],
            "soft_requirements": [],
            "position": "",
            "keywords": [],
            "raw_text": jd_text,
            "filtered_text": "",
            "is_brief": False,
        }

        # 过滤福利套话
        filtered = jd_text
        for kw in JD_FILTER_KEYWORDS:
            filtered = re.sub(rf'[^。\n]*?{re.escape(kw)}[^。\n]*?[。\n]?', '', filtered)
        result["filtered_text"] = filtered.strip()

        # 提取岗位名称
        pos_match = re.search(r'(?:岗位|职位|招聘)[:：\s]*([^\s,，。\n]{2,30})', jd_text)
        if not pos_match:
            pos_match = re.search(r'^([^\s,，。\n]{2,20}(?:工程师|经理|专员|总监|开发|设计师|运营|产品))', jd_text)
        if pos_match:
            result["position"] = pos_match.group(1).strip()

        # 提取硬性要求
        result["hard_requirements"] = InfoExtractor._extract_hard_requirements(filtered)

        # 提取软性要求
        result["soft_requirements"] = InfoExtractor._extract_soft_requirements(filtered)

        # 提取核心关键词
        result["keywords"] = InfoExtractor._extract_keywords(filtered)

        # 判断JD是否过于简短
        if len(jd_text.strip()) < 100:
            result["is_brief"] = True

        return result

    @staticmethod
    def _extract_hard_requirements(text: str) -> List[str]:
        """提取硬性要求（学历、年限、技能等）"""
        requirements = []

        # 学历要求
        degree_match = re.search(r'(?:学历|要求)[:：\s]*[^。]*?(博士|硕士|本科|大专|研究生)[^。]*', text)
        if degree_match:
            requirements.append(f"学历要求: {degree_match.group(0).strip()}")

        # 工作年限
        year_match = re.search(r'[^。]*?(\d+[-~]\d+年|[3-9]年以上|应届).*?(?:经验|工作)[^。]*', text)
        if year_match:
            requirements.append(f"经验要求: {year_match.group(0).strip()}")

        # 技能要求
        for category, keywords in SKILL_KEYWORDS.items():
            found = [kw for kw in keywords if kw.lower() in text.lower()]
            if found:
                requirements.append(f"技能要求({category}): {', '.join(found[:5])}")

        # 证书要求
        cert_match = re.findall(r'(?:持有|具备|拥有)[^。]*?(?:证书|认证|PMP|CFA|CPA)[^。]*', text)
        for c in cert_match:
            requirements.append(f"证书要求: {c.strip()}")

        return requirements

    @staticmethod
    def _extract_soft_requirements(text: str) -> List[str]:
        """提取软性要求（沟通、协作、逻辑等）"""
        soft_keywords = [
            "沟通", "协作", "逻辑", "学习能力", "抗压", "责任心",
            "自驱", "owner", "团队合作", "主动", "解决问题",
            "创新", "执行力", "推动", "跨部门", "项目管理",
        ]
        found = []
        for kw in soft_keywords:
            if kw.lower() in text.lower():
                found.append(kw)
        return found

    @staticmethod
    def _extract_keywords(text: str) -> List[str]:
        """提取JD核心关键词（去重、排序）"""
        import jieba

        # 过滤停用词
        stop_words = {
            "的", "了", "在", "是", "我", "有", "和", "就", "不", "人", "都", "一",
            "一个", "上", "也", "很", "到", "说", "要", "去", "你", "会", "着",
            "没有", "看", "好", "自己", "这", "能够", "进行", "负责", "参与",
            "以上", "优先", "具有", "相关", "以下", "以上", "任职",
        }

        words = jieba.cut(text)
        word_freq = {}
        for w in words:
            w = w.strip()
            if len(w) >= 2 and w not in stop_words:
                word_freq[w] = word_freq.get(w, 0) + 1

        # 按频率排序，取前20
        sorted_words = sorted(word_freq.items(), key=lambda x: x[1], reverse=True)
        return [w for w, _ in sorted_words[:20]]
