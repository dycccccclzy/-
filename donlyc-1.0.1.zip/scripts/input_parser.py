"""
Step 1: 输入解析模块
支持 PDF / Word / 图片OCR / 纯文本 四种格式
"""

import os
import re
import io
from typing import Optional, Tuple


class InputParser:
    """简历和JD输入解析器"""

    SUPPORTED_FORMATS = {".pdf", ".docx", ".doc", ".png", ".jpg", ".jpeg", ".txt", ".md"}

    @staticmethod
    def detect_format(file_path: str) -> str:
        """检测文件格式"""
        ext = os.path.splitext(file_path)[1].lower()
        if ext not in InputParser.SUPPORTED_FORMATS:
            raise ValueError(f"不支持的文件格式: {ext}，支持的格式: {InputParser.SUPPORTED_FORMATS}")
        return ext

    @staticmethod
    def parse_file(file_path: str) -> str:
        """
        根据文件格式自动选择解析方式
        返回提取的纯文本内容
        """
        if not os.path.exists(file_path):
            raise FileNotFoundError(f"文件不存在: {file_path}")

        ext = InputParser.detect_format(file_path)

        if ext == ".pdf":
            return InputParser._parse_pdf(file_path)
        elif ext in {".docx", ".doc"}:
            return InputParser._parse_docx(file_path)
        elif ext in {".png", ".jpg", ".jpeg"}:
            return InputParser._parse_image(file_path)
        elif ext in {".txt", ".md"}:
            return InputParser._parse_text(file_path)
        else:
            raise ValueError(f"无法解析的文件格式: {ext}")

    @staticmethod
    def parse_text(text: str) -> str:
        """直接解析纯文本输入"""
        if not text or not text.strip():
            raise ValueError("输入的文本内容为空")
        return text.strip()

    @staticmethod
    def _parse_pdf(file_path: str) -> str:
        """解析PDF文件"""
        text = ""
        # 优先使用 pdfplumber（效果更好）
        try:
            import pdfplumber
            with pdfplumber.open(file_path) as pdf:
                for page in pdf.pages:
                    page_text = page.extract_text()
                    if page_text:
                        text += page_text + "\n"
            if text.strip():
                return text.strip()
        except ImportError:
            pass
        except Exception:
            pass

        # 降级使用 PyPDF2
        try:
            from PyPDF2 import PdfReader
            reader = PdfReader(file_path)
            for page in reader.pages:
                page_text = page.extract_text()
                if page_text:
                    text += page_text + "\n"
            return text.strip()
        except ImportError:
            raise ImportError("请安装 pdfplumber 或 PyPDF2: pip install pdfplumber PyPDF2")
        except Exception as e:
            raise RuntimeError(f"PDF解析失败: {e}")

    @staticmethod
    def _parse_docx(file_path: str) -> str:
        """解析Word文档"""
        try:
            from docx import Document
            doc = Document(file_path)
            text_parts = []
            for para in doc.paragraphs:
                if para.text.strip():
                    text_parts.append(para.text.strip())
            # 也读取表格中的内容
            for table in doc.tables:
                for row in table.rows:
                    row_text = " | ".join(cell.text.strip() for cell in row.cells if cell.text.strip())
                    if row_text:
                        text_parts.append(row_text)
            return "\n".join(text_parts)
        except ImportError:
            raise ImportError("请安装 python-docx: pip install python-docx")
        except Exception as e:
            raise RuntimeError(f"Word文档解析失败: {e}")

    @staticmethod
    def _parse_image(file_path: str) -> str:
        """OCR识别图片中的文字"""
        try:
            from PIL import Image
            import pytesseract

            img = Image.open(file_path)
            # 中文+英文混合识别
            text = pytesseract.image_to_string(img, lang="chi_sim+eng")
            return text.strip()
        except ImportError as e:
            if "PIL" in str(e):
                raise ImportError("请安装 Pillow: pip install Pillow")
            elif "pytesseract" in str(e):
                raise ImportError(
                    "请安装 pytesseract: pip install pytesseract\n"
                    "并安装 Tesseract-OCR: https://github.com/UB-Mannheim/tesseract/wiki"
                )
            raise
        except Exception as e:
            raise RuntimeError(f"图片OCR识别失败: {e}")

    @staticmethod
    def _parse_text(file_path: str) -> str:
        """解析纯文本文件"""
        encodings = ["utf-8", "gbk", "gb2312", "latin-1"]
        for encoding in encodings:
            try:
                with open(file_path, "r", encoding=encoding) as f:
                    content = f.read().strip()
                    if content:
                        return content
            except (UnicodeDecodeError, UnicodeError):
                continue
        raise RuntimeError(f"无法识别文件编码: {file_path}")

    @staticmethod
    def validate_inputs(resume_text: Optional[str], jd_text: Optional[str]) -> Tuple[bool, str]:
        """
        校验输入完整性
        返回 (是否完整, 提示信息)
        """
        missing = []
        if not resume_text or not resume_text.strip():
            missing.append("简历")
        if not jd_text or not jd_text.strip():
            missing.append("JD（岗位描述）")

        if missing:
            return False, f"请提供{'和'.join(missing)}内容。可以上传文件(PDF/Word/图片/文本)或直接粘贴文本。"

        if len(resume_text.strip()) < 20:
            return False, "简历内容过短，请提供完整的简历信息。"

        if len(jd_text.strip()) < 20:
            return False, "JD内容过短，请提供完整的岗位描述。"

        return True, "输入完整"
