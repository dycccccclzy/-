"""
主程序入口 - 简历-JD智能匹配分析系统

完整6+1步工作流：
Step 1: 输入识别与解析
Step 2: 信息抽取
Step 3: 百分制权重打分
Step 4: 生成匹配报告
Step 5: 生成打招呼语
Step 6: 格式化输出
Step 7: JD定向简历改写（按需触发）

用法：
    python main.py                    # 交互式模式
    python main.py --resume <文件> --jd <文件>   # 文件模式
    python main.py --resume <文件> --jd <文件> --rewrite  # 文件+改写模式
"""

import os
import sys
import argparse
from typing import Optional

# Skill scripts 目录中的模块都是同级导入
_current_dir = os.path.dirname(os.path.abspath(__file__))
if _current_dir not in sys.path:
    sys.path.insert(0, _current_dir)

from input_parser import InputParser
from info_extractor import InfoExtractor
from scoring_engine import ScoringEngine
from output_formatter import OutputFormatter
from resume_rewriter import ResumeRewriter


class ResumeJDMatcher:
    """简历-JD智能匹配分析系统主类"""

    def __init__(self):
        self.parser = InputParser()
        self.extractor = InfoExtractor()
        self.scorer = ScoringEngine()
        self.formatter = OutputFormatter()
        self.rewriter = ResumeRewriter()

    def run(self, resume_text: str, jd_text: str, do_rewrite: bool = False) -> str:
        """
        执行完整的6+1步工作流

        参数:
            resume_text: 简历文本内容
            jd_text: JD文本内容
            do_rewrite: 是否执行Step7简历改写

        返回:
            完整的格式化分析报告
        """
        # Step 1: 输入校验
        is_valid, message = self.parser.validate_inputs(resume_text, jd_text)
        if not is_valid:
            return f"[错误] 输入校验失败：{message}"

        # Step 2: 信息抽取
        resume_data = self.extractor.extract_resume(resume_text)
        jd_data = self.extractor.extract_jd(jd_text)

        # Step 3: 打分
        score_result = self.scorer.score(resume_data, jd_data)

        # Step 4-6: 格式化输出
        output = self.formatter.format_full_output(score_result, resume_data, jd_data)

        # Step 7: 简历改写（按需）
        if do_rewrite:
            rewrite_output = self.rewriter.rewrite(resume_data, jd_data, score_result)
            output += "\n" + "=" * 60 + "\n\n"
            output += rewrite_output

        return output

    def run_interactive(self):
        """交互式运行模式"""
        print("=" * 60)
        print("  简历-JD智能匹配分析系统 v2.0")
        print("  支持：匹配打分 | 人岗分析 | 打招呼语 | 简历改写")
        print("=" * 60)
        print()

        # 获取简历
        resume_text = self._get_input("简历", "请提供简历内容（文件路径/纯文本）：")

        # 获取JD
        jd_text = self._get_input("JD", "请提供JD/岗位描述（文件路径/纯文本）：")

        # 询问是否需要改写
        print()
        rewrite_choice = input("是否需要根据JD定向改写简历项目经历？(y/n，默认n): ").strip().lower()
        do_rewrite = rewrite_choice in ("y", "yes", "是")

        print()
        print("正在分析中...")
        print("=" * 60)
        print()

        # 执行分析
        result = self.run(resume_text, jd_text, do_rewrite)
        print(result)

        # 保存结果
        save_choice = input("\n是否保存分析结果到文件？(y/n，默认n): ").strip().lower()
        if save_choice in ("y", "yes", "是"):
            self._save_result(result)

    def _get_input(self, label: str, prompt: str) -> str:
        """获取用户输入（文件路径或纯文本）"""
        while True:
            user_input = input(prompt).strip()

            if not user_input:
                print(f"[警告] {label}内容不能为空，请重新输入。")
                continue

            # 判断是否为文件路径
            if os.path.exists(user_input):
                try:
                    text = self.parser.parse_file(user_input)
                    print(f"[成功] 已从文件读取{label}内容（{len(text)}字符）")
                    return text
                except Exception as e:
                    print(f"[警告] 文件读取失败: {e}")
                    print("将作为纯文本处理...")
                    return user_input

            # 纯文本
            if len(user_input) < 20:
                confirm = input(f"[警告] {label}内容较短({len(user_input)}字符)，确认继续？(y/n): ").strip().lower()
                if confirm not in ("y", "yes", "是"):
                    continue

            return user_input

    def _save_result(self, result: str):
        """保存分析结果到文件"""
        default_dir = os.path.dirname(os.path.abspath(__file__))
        filename = os.path.join(default_dir, "analysis_result.txt")

        counter = 1
        while os.path.exists(filename):
            filename = os.path.join(default_dir, f"analysis_result_{counter}.txt")
            counter += 1

        try:
            with open(filename, "w", encoding="utf-8") as f:
                f.write(result)
            print(f"[成功] 结果已保存至: {filename}")
        except Exception as e:
            print(f"[错误] 保存失败: {e}")


def main():
    """命令行入口"""
    # 修复Windows GBK编码问题
    import io
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')

    parser = argparse.ArgumentParser(
        description="简历-JD智能匹配分析系统",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
示例用法:
  python main.py                                                    # 交互式模式
  python main.py -r resume.pdf -j jd.txt                           # 文件模式
  python main.py -r resume.docx -j jd.txt --rewrite                # 文件+改写模式
  python main.py -r "我是简历文本..." -j "招聘要求..." --rewrite     # 纯文本模式
        """
    )
    parser.add_argument("-r", "--resume", help="简历文件路径或纯文本内容")
    parser.add_argument("-j", "--jd", help="JD文件路径或纯文本内容")
    parser.add_argument("--rewrite", action="store_true", help="启用JD定向简历项目改写")
    parser.add_argument("--save", action="store_true", help="自动保存分析结果")

    args = parser.parse_args()

    matcher = ResumeJDMatcher()

    # 交互式模式
    if not args.resume and not args.jd:
        matcher.run_interactive()
        return

    # 命令行模式
    if not args.resume:
        print("[错误] 请通过 -r/--resume 提供简历内容")
        sys.exit(1)
    if not args.jd:
        print("[错误] 请通过 -j/--jd 提供JD内容")
        sys.exit(1)

    # 解析简历
    if os.path.exists(args.resume):
        resume_text = matcher.parser.parse_file(args.resume)
    else:
        resume_text = args.resume

    # 解析JD
    if os.path.exists(args.jd):
        jd_text = matcher.parser.parse_file(args.jd)
    else:
        jd_text = args.jd

    # 执行分析
    result = matcher.run(resume_text, jd_text, do_rewrite=args.rewrite)
    print(result)

    # 自动保存
    if args.save:
        matcher._save_result(result)


if __name__ == "__main__":
    main()
