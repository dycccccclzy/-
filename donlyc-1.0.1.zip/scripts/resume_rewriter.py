"""
Step 7: JD定向简历项目改写模块（核心新增功能）

改写原则：
1. 真实底线：不编造不存在的项目、数据、工作内容
2. JD优先：植入JD高频关键词
3. 量化升级：定性→量化表达
4. 结构统一：项目背景→个人负责模块→落地动作→业务成果
5. 双版本输出：精简版 + 完整版
6. 标注改写说明

区分人群：职场社招 / 应届生 / 转行求职者
"""

import re
from typing import Dict, Any, List, Tuple, Optional

try:
    from .config import (
        QUANTIFY_MAPPING, PROJECT_STRUCTURE_TEMPLATE,
        FRESHER_KEYWORDS, CAREER_TRANSFER_MAPPING, REWRITE_TRIGGER_KEYWORDS
    )
except ImportError:
    from config import (
        QUANTIFY_MAPPING, PROJECT_STRUCTURE_TEMPLATE,
        FRESHER_KEYWORDS, CAREER_TRANSFER_MAPPING, REWRITE_TRIGGER_KEYWORDS
    )


class ResumeRewriter:
    """JD定向简历项目改写器"""

    def __init__(self):
        self.trigger_keywords = REWRITE_TRIGGER_KEYWORDS

    def should_trigger(self, user_message: str) -> bool:
        """判断用户消息是否触发改写功能"""
        msg_lower = user_message.lower()
        for kw in self.trigger_keywords:
            if kw.lower() in msg_lower:
                return True
        return False

    def rewrite(
        self,
        resume_data: Dict[str, Any],
        jd_data: Dict[str, Any],
        score_result: Dict[str, Any],
    ) -> str:
        """
        执行简历项目改写
        返回格式化后的改写输出
        """
        projects = resume_data.get("project_experience", [])
        if not projects:
            return (
                "【JD定向优化·简历项目改写】\n\n"
                "[提示] 简历暂无项目经验，无法进行项目改写。\n"
                "可补充实习/工作项目后再次优化。"
            )

        is_fresher = resume_data.get("is_fresher", False)
        is_career_changer = resume_data.get("is_career_changer", False)
        is_brief_jd = jd_data.get("is_brief", False)

        # 执行改写
        rewritten_projects = self._rewrite_projects(
            projects, jd_data, is_fresher, is_career_changer
        )

        # 生成双版本
        output_parts = []

        output_parts.append("【JD定向优化·简历项目改写】")

        if is_brief_jd:
            output_parts.append("")
            output_parts.append("[提示] JD需求较少，改写基于现有有限关键词优化，可补充完整岗位要求进一步细化。")
            output_parts.append("")

        # 版本A：精简版
        output_parts.append("### 版本1｜精简版（招聘平台在线简历使用）")
        output_parts.append("")
        for i, proj in enumerate(rewritten_projects, 1):
            output_parts.append(f"项目{i}：{proj.get('name', '未命名项目')}")
            output_parts.append(f"优化后内容：{proj['brief_version']}")
            output_parts.append("")

        # 版本B：完整版
        output_parts.append("### 版本2｜完整版（正式Word简历投递使用）")
        output_parts.append("")
        for i, proj in enumerate(rewritten_projects, 1):
            output_parts.append(f"项目{i}：{proj.get('name', '未命名项目')}")
            output_parts.append(f"优化后完整描述：")
            output_parts.append(proj['full_version'])
            output_parts.append("")

        # 改写对标说明
        output_parts.append("### 改写对标说明")
        output_parts.append("")
        for i, proj in enumerate(rewritten_projects, 1):
            output_parts.append(f"--- 项目{i}：{proj.get('name', '未命名项目')} ---")
            for j, mapping in enumerate(proj.get('rewrite_mappings', []), 1):
                output_parts.append(
                    f"{j}. 原简历：{mapping['original']}"
                    f"｜优化点：{mapping['change']}"
                    f"｜匹配JD需求：{mapping['jd_requirement']}"
                )
            output_parts.append("")

        return "\n".join(output_parts)

    def _rewrite_projects(
        self,
        projects: List[Dict],
        jd_data: Dict,
        is_fresher: bool,
        is_career_changer: bool,
    ) -> List[Dict]:
        """
        对每个项目执行改写
        """
        jd_keywords = jd_data.get("keywords", [])
        jd_hard = jd_data.get("hard_requirements", [])
        jd_soft = jd_data.get("soft_requirements", [])
        jd_text = jd_data.get("raw_text", "")
        jd_position = jd_data.get("position", "")
        jd_filtered = jd_data.get("filtered_text", "")

        # 提取JD中的高频技术词（2字以上）
        jd_tech_words = self._extract_jd_tech_words(jd_filtered)

        rewritten = []
        for proj in projects:
            original_desc = proj.get("description", "")
            original_name = proj.get("name", "未命名项目")

            # 分析原始描述
            analyzed = self._analyze_original(original_desc)

            # 匹配JD关键词
            matched_keywords = self._match_jd_keywords(original_desc, jd_keywords, jd_tech_words)

            # 根据人群调整改写策略
            if is_fresher:
                rewrite_strategy = "fresher"
            elif is_career_changer:
                rewrite_strategy = "career_changer"
            else:
                rewrite_strategy = "professional"

            # 生成改写
            brief = self._generate_brief_version(
                analyzed, matched_keywords, jd_position, rewrite_strategy
            )
            full = self._generate_full_version(
                analyzed, matched_keywords, jd_position, rewrite_strategy
            )

            # 生成对标说明
            mappings = self._generate_mappings(
                original_desc, analyzed, matched_keywords, jd_hard, jd_soft, rewrite_strategy
            )

            rewritten.append({
                "name": original_name,
                "brief_version": brief,
                "full_version": full,
                "rewrite_mappings": mappings,
            })

        return rewritten

    def _extract_jd_tech_words(self, jd_text: str) -> List[str]:
        """从JD中提取技术/业务关键词（排除通用词）"""
        stop_words = {
            "负责", "参与", "相关", "以上", "优先", "具有", "能够", "进行",
            "工作", "经验", "要求", "任职", "岗位", "职位", "职责", "描述",
            "团队", "能力", "我们", "公司", "业务", "提供", "包括",
            "熟悉", "了解", "掌握", "精通", "使用", "开发", "设计",
        }
        import jieba
        words = jieba.cut(jd_text)
        tech_words = []
        for w in words:
            w = w.strip()
            if len(w) >= 2 and w not in stop_words and not w.isdigit():
                tech_words.append(w)
        # 去重保持顺序
        seen = set()
        unique = []
        for w in tech_words:
            if w not in seen:
                seen.add(w)
                unique.append(w)
        return unique[:30]

    def _analyze_original(self, description: str) -> Dict[str, Any]:
        """分析原始项目描述"""
        return {
            "raw": description,
            "has_background": bool(re.search(r'背景|目标|目的|需求|场景', description)),
            "has_role": bool(re.search(r'负责|承担|主导|参与|角色|职责', description)),
            "has_action": bool(re.search(r'开发|设计|实现|搭建|优化|重构|部署|测试|上线', description)),
            "has_result": bool(re.search(r'\d+%|\d+万|提升|增长|降低|缩短|完成|交付|上线', description)),
            "tech_mentions": re.findall(r'[A-Z][a-zA-Z+#]+|[\u4e00-\u9fff]{2,6}(?:框架|平台|系统|工具)', description),
            "data_mentions": re.findall(r'\d+[%万千百倍个]', description),
        }

    def _match_jd_keywords(
        self, description: str, jd_keywords: List[str], jd_tech_words: List[str]
    ) -> Dict[str, List[str]]:
        """匹配JD关键词"""
        desc_lower = description.lower()

        already_matched = [kw for kw in jd_keywords if kw.lower() in desc_lower]
        can_add = [kw for kw in jd_tech_words if kw.lower() not in desc_lower]

        return {
            "matched": already_matched[:8],
            "can_add": can_add[:8],
        }

    def _generate_brief_version(
        self,
        analyzed: Dict,
        matched_keywords: Dict,
        jd_position: str,
        strategy: str,
    ) -> str:
        """生成精简版（招聘平台使用）"""
        raw = analyzed["raw"]
        matched = matched_keywords.get("matched", [])
        can_add = matched_keywords.get("can_add", [])

        # 精简版：每行一句话，关键词前置
        lines = []

        # 提取核心动作
        action_phrases = re.findall(
            r'(?:负责|主导|参与)?[^。，\n]{5,30}(?:开发|设计|搭建|优化|实现|重构|部署|上线|交付|完成)[^。，\n]*',
            raw
        )

        if action_phrases:
            # 取前3句，加入JD关键词
            for phrase in action_phrases[:3]:
                cleaned = phrase.strip().rstrip("，,。.")
                # 尝试加入一个JD关键词
                enriched = self._enrich_with_keyword(cleaned, matched, can_add, strategy)
                lines.append(f"- {enriched}")
        else:
            # 如果没有明确动作，整理原文
            sentences = re.split(r'[。；;]', raw)
            for s in sentences[:3]:
                s = s.strip()
                if len(s) > 10:
                    enriched = self._enrich_with_keyword(s, matched, can_add, strategy)
                    lines.append(f"- {enriched}")

        # 加入量化成果
        if analyzed["has_result"]:
            data_mentions = analyzed.get("data_mentions", [])
            if data_mentions:
                lines.append(f"- 成果：{', '.join(data_mentions[:3])}")
        else:
            # 引导量化
            for phrase in raw.split("。"):
                for qual_word, quant_guide in QUANTIFY_MAPPING.items():
                    if qual_word in phrase:
                        lines.append(f"- {quant_guide}（可补充具体数据）")
                        break

        if strategy == "fresher":
            lines.insert(0, f"- 在校期间{lines[0].lstrip('- ')}" if lines else "- 在校期间参与相关实践")
        elif strategy == "career_changer":
            # 弱化原行业词汇
            lines = [self._neutralize_industry_terms(l) for l in lines]

        return "\n".join(lines) if lines else raw[:200]

    def _generate_full_version(
        self,
        analyzed: Dict,
        matched_keywords: Dict,
        jd_position: str,
        strategy: str,
    ) -> str:
        """生成完整版（Word正式简历使用）"""
        raw = analyzed["raw"]
        matched = matched_keywords.get("matched", [])
        can_add = matched_keywords.get("can_add", [])

        # 按照 PROJECT_STRUCTURE_TEMPLATE 结构组织
        # 项目背景 → 个人负责模块 → 落地动作 → 业务成果

        parts = []

        # 1. 项目背景
        background = self._extract_or_generate_background(raw, jd_position, strategy)
        parts.append(f"【项目背景】{background}")

        # 2. 个人负责模块
        role = self._extract_or_generate_role(raw, strategy)
        parts.append(f"【个人职责】{role}")

        # 3. 落地动作（嵌入JD关键词）
        actions = self._extract_or_generate_actions(raw, matched, can_add, strategy)
        parts.append(f"【关键动作】{actions}")

        # 4. 业务成果
        result = self._extract_or_generate_result(raw, strategy)
        parts.append(f"【业务成果】{result}")

        return "\n".join(parts)

    def _extract_or_generate_background(self, desc: str, jd_position: str, strategy: str) -> str:
        """提取或生成项目背景"""
        bg_match = re.search(r'(?:背景|目标|目的|需求|场景)[:：]?\s*([^。\n]+)', desc)
        if bg_match:
            return bg_match.group(1).strip()

        # 尝试从描述前部提取
        first_sentence = desc.split("。")[0].strip()
        if len(first_sentence) < 100:
            return first_sentence

        if strategy == "fresher":
            return f"为提升专业技能，参与{jd_position}方向实践项目"
        return f"基于业务需求，负责{jd_position}方向相关工作"

    def _extract_or_generate_role(self, desc: str, strategy: str) -> str:
        """提取或生成个人职责描述"""
        role_match = re.search(r'(?:负责|承担|主导|担任)[:：]?\s*([^。\n]+)', desc)
        if role_match:
            return role_match.group(0).strip()

        if strategy == "fresher":
            return "作为核心成员参与项目开发与落地"
        return "独立负责核心模块的设计与实现"

    def _extract_or_generate_actions(
        self, desc: str, matched: List[str], can_add: List[str], strategy: str
    ) -> str:
        """提取或生成关键动作描述"""
        action_phrases = re.findall(
            r'[^。\n]{10,60}',
            desc
        )

        selected = []
        for phrase in action_phrases[:4]:
            cleaned = phrase.strip().rstrip("，,。.")
            if len(cleaned) > 15:
                enriched = self._enrich_with_keyword(cleaned, matched, can_add, strategy)
                selected.append(enriched)

        if not selected:
            selected.append(f"完成{desc[:50]}...")

        return "；".join(selected)

    def _extract_or_generate_result(self, desc: str, strategy: str) -> str:
        """提取或生成业务成果"""
        # 查找数据指标
        data_matches = re.findall(
            r'[^。\n]*?(?:\d+[%万千百倍个]|提升|增长|降低|缩短|优化|完成|交付|上线)[^。\n]*',
            desc
        )

        if data_matches:
            return "；".join(data_matches[:3])

        if strategy == "fresher":
            return "项目按时交付并通过验收，获得团队认可（可补充具体成果数据）"
        return "项目顺利交付上线，相关指标可进一步补充量化数据"

    def _enrich_with_keyword(
        self, text: str, matched: List[str], can_add: List[str], strategy: str
    ) -> str:
        """在文本中智能嵌入JD关键词"""
        # 优先使用已匹配的关键词强化
        for kw in matched:
            if kw.lower() not in text.lower():
                # 尝试在适当位置插入
                text = self._insert_keyword(text, kw)
                break

        # 如果没有已匹配的，尝试添加可新增关键词
        if not any(kw.lower() in text.lower() for kw in matched):
            for kw in can_add[:2]:
                if len(kw) >= 2:
                    text = self._insert_keyword(text, kw)
                    break

        return text

    def _insert_keyword(self, text: str, keyword: str) -> str:
        """在文本中智能插入关键词"""
        # 在技术动词前插入
        action_patterns = ["开发", "设计", "实现", "搭建", "优化", "构建"]
        for pattern in action_patterns:
            if pattern in text:
                return text.replace(pattern, f"基于{keyword}{pattern}", 1)

        # 在句首添加
        if len(text) > 5:
            return f"运用{keyword}技术，{text}"

        return f"{keyword} - {text}"

    def _neutralize_industry_terms(self, text: str) -> str:
        """中性化行业术语（用于转行人群）"""
        # 替换原行业专属词汇为通用话术
        for old_industry, transfer_words in CAREER_TRANSFER_MAPPING.items():
            for word in transfer_words:
                if word in text:
                    # 已经是通用词汇，无需替换
                    pass
        return text

    def _generate_mappings(
        self,
        original_desc: str,
        analyzed: Dict,
        matched_keywords: Dict,
        jd_hard: List[str],
        jd_soft: List[str],
        strategy: str,
    ) -> List[Dict[str, str]]:
        """生成改写对标说明"""
        mappings = []
        matched = matched_keywords.get("matched", [])

        # 1. 结构优化说明
        if not analyzed["has_background"]:
            mappings.append({
                "original": "原文缺少项目背景说明",
                "change": "补充项目背景模块，明确业务场景",
                "jd_requirement": "JD要求理解业务场景，具备业务思维",
            })

        if not analyzed["has_role"]:
            mappings.append({
                "original": "原文未明确个人职责分工",
                "change": "增加个人职责模块，突出独立负责范围",
                "jd_requirement": "JD要求独立承担模块/owner意识",
            })

        # 2. JD关键词植入说明
        for kw in matched[:3]:
            mappings.append({
                "original": f"原文涉及{kw}相关内容",
                "change": f"强化{kw}相关描述，前置{kw}能力关键词",
                "jd_requirement": f"JD明确要求掌握{kw}能力",
            })

        # 3. 量化升级说明
        if not analyzed["has_result"]:
            mappings.append({
                "original": "原文缺少量化业务成果",
                "change": "增加业务成果模块，引导补充量化数据（如效率提升XX%、用户增长XX%）",
                "jd_requirement": "JD关注结果导向和数据驱动能力",
            })
        elif analyzed.get("data_mentions"):
            mappings.append({
                "original": f"原文包含数据：{', '.join(analyzed['data_mentions'][:3])}",
                "change": "保留原始真实数据，按结构重新组织呈现",
                "jd_requirement": "JD关注可量化的业务产出",
            })

        # 4. 人群特殊说明
        if strategy == "fresher":
            mappings.append({
                "original": "应届生简历",
                "change": "突出实习/校园项目中的实操技能和协作能力",
                "jd_requirement": "JD对应届生更关注学习能力和项目实操",
            })
        elif strategy == "career_changer":
            mappings.append({
                "original": "转行简历",
                "change": "放大可迁移技能（如沟通协调、项目管理），弱化原行业专属表述",
                "jd_requirement": "JD关注核心通用能力而非特定行业经验",
            })

        return mappings
