"""
Step 3: 百分制权重打分引擎
硬性资质40分｜工作经历35分｜项目经验20分｜综合素养5分
支持应届生/转行人群差异化评分
"""

import re
from typing import Dict, Any, List, Tuple

try:
    from .config import (
        SCORE_WEIGHTS, MATCH_LEVELS, SKILL_KEYWORDS,
        FRESHER_KEYWORDS
    )
    from .info_extractor import InfoExtractor
except ImportError:
    from config import (
        SCORE_WEIGHTS, MATCH_LEVELS, SKILL_KEYWORDS,
        FRESHER_KEYWORDS
    )
    from info_extractor import InfoExtractor


class ScoringEngine:
    """打分引擎"""

    def __init__(self):
        self.weights = SCORE_WEIGHTS
        self.levels = MATCH_LEVELS

    def score(self, resume_data: Dict[str, Any], jd_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        执行完整打分流程
        返回:
        {
            "total_score": int,           # 总分
            "match_level": str,           # 匹配等级
            "sub_scores": {...},          # 各维度得分
            "highlights": [...],          # 匹配亮点
            "gaps": [...],                # 待提升点
            "greeting": str,              # 打招呼语
        }
        """
        is_fresher = resume_data.get("is_fresher", False)
        is_career_changer = resume_data.get("is_career_changer", False)

        # 计算各维度得分
        hard_score, hard_highlights, hard_gaps = self._score_hard_qualification(
            resume_data, jd_data, is_fresher
        )
        work_score, work_highlights, work_gaps = self._score_work_experience(
            resume_data, jd_data, is_fresher, is_career_changer
        )
        project_score, project_highlights, project_gaps = self._score_project_experience(
            resume_data, jd_data, is_fresher
        )
        quality_score, quality_highlights, quality_gaps = self._score_comprehensive_quality(
            resume_data, jd_data
        )

        total = hard_score + work_score + project_score + quality_score

        # 确定匹配等级
        match_level = self._get_match_level(total)

        return {
            "total_score": total,
            "match_level": match_level,
            "sub_scores": {
                "hard_qualification": hard_score,
                "work_experience": work_score,
                "project_experience": project_score,
                "comprehensive_quality": quality_score,
            },
            "highlights": hard_highlights + work_highlights + project_highlights + quality_highlights,
            "gaps": hard_gaps + work_gaps + project_gaps + quality_gaps,
        }

    def _get_match_level(self, score: int) -> str:
        """根据分数确定匹配等级"""
        for (low, high), level in self.levels.items():
            if low <= score <= high:
                return level
        return "低匹配"

    # ==================== 硬性资质评分（40分） ====================

    def _score_hard_qualification(
        self, resume: Dict, jd: Dict, is_fresher: bool
    ) -> Tuple[int, List[str], List[str]]:
        """
        评分维度：
        - 学历匹配度（0-12分）
        - 工作年限匹配度（0-10分）
        - 技能匹配度（0-10分）
        - 证书/资质匹配度（0-8分）
        """
        max_score = self.weights["hard_qualification"]
        highlights = []
        gaps = []

        # 学历匹配
        edu = resume.get("education", {})
        jd_text = jd.get("raw_text", "")
        degree_score, degree_h, degree_g = self._match_degree(edu, jd_text, max_points=12)
        highlights.extend(degree_h)
        gaps.extend(degree_g)

        # 工作年限匹配
        years_score, years_h, years_g = self._match_work_years(resume, jd_text, is_fresher, max_points=10)
        highlights.extend(years_h)
        gaps.extend(years_g)

        # 技能匹配
        skills = resume.get("skills_certs", {})
        tech_skills = skills.get("technical", [])
        jd_keywords = jd.get("keywords", [])
        skill_score, skill_h, skill_g = self._match_skills(tech_skills, jd_keywords, jd_text, max_points=10)
        highlights.extend(skill_h)
        gaps.extend(skill_g)

        # 证书匹配
        cert_score, cert_h, cert_g = self._match_certs(
            skills.get("certificates", []), jd_text, max_points=8
        )
        highlights.extend(cert_h)
        gaps.extend(cert_g)

        total = degree_score + years_score + skill_score + cert_score

        # 应届生调整
        if is_fresher:
            total = min(total + 3, max_score)  # 放宽学历权重

        return total, highlights, gaps

    def _match_degree(self, edu: Dict, jd_text: str, max_points: int) -> Tuple[int, List, List]:
        """学历匹配"""
        degree_hierarchy = {"博士": 5, "硕士": 4, "MBA": 4, "EMBA": 4, "本科": 3, "大专": 2}
        resume_degree = edu.get("degree", "")
        resume_level = degree_hierarchy.get(resume_degree, 0)

        required = ""
        required_level = 0
        for deg, level in degree_hierarchy.items():
            if deg in jd_text:
                required = deg
                required_level = level
                break

        if not required:
            # 未明确要求学历，默认本科
            required_level = 3

        if resume_level >= required_level:
            score = max_points
            if required:
                return score, [f"学历{resume_degree}满足JD{required}要求"], []
            return score, ["学历背景符合岗位要求"], []
        elif resume_level > 0:
            score = int(max_points * 0.5)
            return score, [], [f"学历{resume_degree}低于JD要求的{required}"]
        return 0, [], ["简历中未检测到学历信息"]

    def _match_work_years(
        self, resume: Dict, jd_text: str, is_fresher: bool, max_points: int
    ) -> Tuple[int, List, List]:
        """工作年限匹配"""
        if is_fresher:
            if "应届" in jd_text or "毕业生" in jd_text:
                return max_points, ["应届生身份符合岗位要求"], []
            return int(max_points * 0.6), [], ["JD未明确接受应届生"]

        import re
        year_match = re.search(r'(\d+)[-~]*(\d*)\s*年.*?(?:经验|以上)', jd_text)
        if not year_match:
            return int(max_points * 0.8), [], []

        try:
            min_years = int(year_match.group(1))
        except ValueError:
            return int(max_points * 0.8), [], []

        # 从简历推算工作年限
        basic = resume.get("basic_info", {})
        work_years_str = basic.get("work_years", "")
        resume_years = 0
        years_num = re.search(r'(\d+)', work_years_str)
        if years_num:
            resume_years = int(years_num.group(1))

        if resume_years >= min_years:
            return max_points, [f"{resume_years}年工作经验满足JD{min_years}年要求"], []
        elif resume_years >= min_years - 1:
            score = int(max_points * 0.7)
            return score, [], [f"工作经验{resume_years}年，略低于JD要求的{min_years}年"]
        else:
            score = int(max_points * 0.4)
            return score, [], [f"工作经验{resume_years}年，与JD要求{min_years}年差距较大"]

    def _match_skills(
        self, resume_skills: List[str], jd_keywords: List[str], jd_text: str, max_points: int
    ) -> Tuple[int, List, List]:
        """技能匹配"""
        if not resume_skills:
            return 0, [], ["简历中未提取到技能关键词"]

        # 计算JD中提到的技能关键词
        jd_skills = []
        for category, keywords in SKILL_KEYWORDS.items():
            for kw in keywords:
                if kw.lower() in jd_text.lower():
                    jd_skills.append(kw)

        if not jd_skills:
            return int(max_points * 0.6), ["具备专业技能基础"], []

        # 匹配率
        matched = [s for s in resume_skills if s in jd_skills]
        match_rate = len(matched) / len(jd_skills) if jd_skills else 0

        if match_rate >= 0.8:
            score = max_points
            return score, [f"技能高度匹配：{', '.join(matched[:5])}"], []
        elif match_rate >= 0.5:
            score = int(max_points * 0.7)
            missing = [s for s in jd_skills if s not in resume_skills]
            return score, [f"核心技能匹配：{', '.join(matched[:5])}"], [f"可补充技能：{', '.join(missing[:3])}"]
        else:
            score = int(max_points * 0.4)
            missing = [s for s in jd_skills if s not in resume_skills]
            return score, [], [f"技能匹配度较低，JD要求：{', '.join(jd_skills[:5])}"]

    def _match_certs(
        self, resume_certs: List[str], jd_text: str, max_points: int
    ) -> Tuple[int, List, List]:
        """证书匹配"""
        if not resume_certs:
            # 检查JD是否要求证书
            if any(kw in jd_text for kw in ["证书", "认证", "PMP", "CFA"]):
                return 0, [], ["JD有证书要求但简历中未体现"]
            return max_points, [], []

        return max_points, [f"持有相关证书：{', '.join(resume_certs[:3])}"], []

    # ==================== 工作经历评分（35分） ====================

    def _score_work_experience(
        self, resume: Dict, jd: Dict, is_fresher: bool, is_career_changer: bool
    ) -> Tuple[int, List[str], List[str]]:
        """
        评分维度：
        - 行业/业务相关性（0-15分）
        - 职责匹配度（0-12分）
        - 工作稳定性/成长性（0-8分）
        """
        max_score = self.weights["work_experience"]
        highlights = []
        gaps = []

        work_exp = resume.get("work_experience", [])
        jd_keywords = jd.get("keywords", [])
        jd_text = jd.get("raw_text", "")
        jd_position = jd.get("position", "")

        if is_fresher:
            # 应届生侧重实习经历
            if work_exp:
                score = int(max_score * 0.7)
                return score, ["有相关实习经历"], ["建议丰富实习和项目经验"]
            return int(max_score * 0.4), [], ["暂无工作/实习经历"]

        if is_career_changer:
            # 转行人群放宽行业匹配
            if work_exp:
                score = int(max_score * 0.6)
                return score, ["有多元行业背景"], ["需在简历中突出可迁移技能"]
            return 0, [], ["暂无工作经历"]

        if not work_exp:
            return 0, [], ["简历中未提取到工作经历"]

        # 行业/业务相关性
        relevance_score = 0
        for exp in work_exp:
            desc = exp.get("description", "").lower()
            for kw in jd_keywords:
                if kw.lower() in desc:
                    relevance_score += 2
        relevance_score = min(relevance_score, 15)

        if relevance_score >= 12:
            highlights.append("工作经历与JD业务方向高度相关")
        elif relevance_score >= 6:
            highlights.append("工作经历与JD有一定业务相关性")
        else:
            gaps.append("工作经历与JD业务方向关联度偏低")

        # 职责匹配度
        duty_score = 0
        jd_position_lower = jd_position.lower()
        for exp in work_exp:
            pos = exp.get("position", "").lower()
            if pos and jd_position_lower and (
                pos in jd_position_lower or jd_position_lower in pos
            ):
                duty_score += 6
                break

        if duty_score > 0:
            highlights.append(f"过往职位与JD岗位{jd_position}匹配")

        # 工作稳定性
        stability_score = 0
        if len(work_exp) >= 2:
            stability_score = 4
            highlights.append("工作经历丰富且稳定")
        else:
            stability_score = 2

        total = relevance_score + duty_score + stability_score
        return min(total, max_score), highlights, gaps

    # ==================== 项目经验评分（20分） ====================

    def _score_project_experience(
        self, resume: Dict, jd: Dict, is_fresher: bool
    ) -> Tuple[int, List[str], List[str]]:
        """
        评分维度：
        - 项目数量与复杂度（0-8分）
        - 项目与JD技术栈匹配度（0-8分）
        - 项目成果量化程度（0-4分）
        """
        max_score = self.weights["project_experience"]
        highlights = []
        gaps = []

        projects = resume.get("project_experience", [])
        jd_keywords = jd.get("keywords", [])
        jd_text = jd.get("raw_text", "")

        if not projects:
            return 0, [], ["简历中未提取到项目经验"]

        # 项目数量
        count_score = min(len(projects) * 2, 8)

        # 技术栈匹配
        tech_match_score = 0
        for proj in projects:
            tech_stack = proj.get("tech_stack", [])
            desc = proj.get("description", "")
            for kw in jd_keywords:
                if kw.lower() in desc.lower():
                    tech_match_score += 1
            for tech in tech_stack:
                if tech.lower() in jd_text.lower():
                    tech_match_score += 2
        tech_match_score = min(tech_match_score, 8)

        if tech_match_score >= 6:
            highlights.append("项目技术栈与JD高度匹配")
        elif tech_match_score >= 3:
            highlights.append("项目技术栈与JD部分匹配")
        else:
            gaps.append("项目技术栈与JD匹配度偏低")

        # 量化程度
        quantify_score = 0
        for proj in projects:
            desc = proj.get("description", "")
            # 检测数据指标
            if re.search(r'\d+%|\d+万|\d+倍|提升|增长|降低|缩短', desc):
                quantify_score += 2
        quantify_score = min(quantify_score, 4)

        if quantify_score >= 3:
            highlights.append("项目成果有较好的数据量化")
        else:
            gaps.append("建议对项目成果进行量化描述")

        total = count_score + tech_match_score + quantify_score

        if is_fresher:
            total = min(total + 2, max_score)

        return min(total, max_score), highlights, gaps

    # ==================== 综合素养评分（5分） ====================

    def _score_comprehensive_quality(
        self, resume: Dict, jd: Dict
    ) -> Tuple[int, List[str], List[str]]:
        """
        评分维度：
        - 软技能匹配（0-3分）
        - 简历完整度与表达（0-2分）
        """
        max_score = self.weights["comprehensive_quality"]
        highlights = []
        gaps = []

        jd_soft = jd.get("soft_requirements", [])
        resume_text = resume.get("raw_text", "")

        # 软技能匹配
        soft_score = 0
        matched_soft = []
        for skill in jd_soft:
            if skill.lower() in resume_text.lower():
                soft_score += 1
                matched_soft.append(skill)
        soft_score = min(soft_score, 3)

        if matched_soft:
            highlights.append(f"软技能匹配：{', '.join(matched_soft)}")

        # 简历完整度
        completeness = 0
        if resume.get("basic_info", {}).get("name"):
            completeness += 0.5
        if resume.get("education", {}).get("degree"):
            completeness += 0.5
        if resume.get("work_experience", []):
            completeness += 0.5
        if resume.get("project_experience", []):
            completeness += 0.5

        if completeness < 1.5:
            gaps.append("简历信息可进一步完善，建议补充教育、项目等模块")

        total = soft_score + completeness
        return min(total, max_score), highlights, gaps
