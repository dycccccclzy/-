"""
Step 4 & 5: 输出格式化模块
三段式输出：整体匹配得分 + 匹配亮点&差距 + Boss打招呼语
"""

import random
from typing import Dict, Any, List

try:
    from .config import GREETING_TEMPLATES
except ImportError:
    from config import GREETING_TEMPLATES


class OutputFormatter:
    """输出格式化器"""

    @staticmethod
    def format_full_output(score_result: Dict[str, Any], resume: Dict, jd: Dict) -> str:
        """
        格式化完整的三段式输出
        """
        total = score_result["total_score"]
        level = score_result["match_level"]
        highlights = score_result.get("highlights", [])
        gaps = score_result.get("gaps", [])
        sub_scores = score_result.get("sub_scores", {})

        output_parts = []

        # ========== 模块1：整体匹配得分 ==========
        output_parts.append("【人岗整体匹配度】")
        output_parts.append(f"最终得分：{total}分 | 匹配等级：{level}")
        output_parts.append("")
        output_parts.append(f"各维度得分：")
        output_parts.append(f"  - 硬性资质：{sub_scores.get('hard_qualification', 0)}/40分")
        output_parts.append(f"  - 工作经历：{sub_scores.get('work_experience', 0)}/35分")
        output_parts.append(f"  - 项目经验：{sub_scores.get('project_experience', 0)}/20分")
        output_parts.append(f"  - 综合素养：{sub_scores.get('comprehensive_quality', 0)}/5分")
        output_parts.append("")

        # ========== 模块2：匹配亮点 ==========
        output_parts.append("【核心匹配亮点（精准对标JD）】")
        if highlights:
            for i, h in enumerate(highlights, 1):
                output_parts.append(f"{i}、{h}")
        else:
            output_parts.append("暂无显著匹配亮点，建议根据JD要求补充相关经历。")
        output_parts.append("")

        # ========== 模块3：待提升点 ==========
        output_parts.append("【人岗差异待提升点】")
        if gaps:
            for i, g in enumerate(gaps, 1):
                output_parts.append(f"{i}、{g}")
        else:
            output_parts.append("无明显差距，简历与岗位匹配度良好。")
        output_parts.append("")

        # ========== 模块4：Boss打招呼语 ==========
        output_parts.append("【Boss直聘专属打招呼语】")
        greeting = OutputFormatter._generate_greeting(level, resume, jd)
        output_parts.append(greeting)
        output_parts.append("")

        return "\n".join(output_parts)

    @staticmethod
    def _generate_greeting(level: str, resume: Dict, jd: Dict) -> str:
        """根据匹配等级生成专属打招呼语"""
        position = jd.get("position", "该岗位")

        # 从简历提取关键信息
        company = ""
        work_exp = resume.get("work_experience", [])
        if work_exp:
            company = work_exp[0].get("company", "相关企业")

        skills = resume.get("skills_certs", {}).get("technical", [])
        skill_str = "、".join(skills[:3]) if skills else "相关技能"

        basic = resume.get("basic_info", {})
        years = basic.get("work_years", "")

        highlights = []
        for proj in resume.get("project_experience", []):
            name = proj.get("name", "")
            if name:
                highlights.append(name)

        # 根据等级选择模板
        templates = GREETING_TEMPLATES.get(level, GREETING_TEMPLATES["低匹配"])
        template = random.choice(templates)

        # 填充变量
        greeting = template.format(
            position=position,
            company=company if company else "相关企业",
            skill=skill_str,
            field=position[:4] if len(position) >= 4 else position,
            year=years if years else "多",
            highlight="、".join(highlights[:2]) if highlights else "核心项目",
        )

        # 根据等级追加个性化建议
        if level == "高度匹配":
            greeting += "\n\n[投递建议] 匹配度高，建议直接投递并附上完整简历。"
        elif level == "中度匹配":
            greeting += "\n\n[投递建议] 可在沟通中主动提及JD最看重的技能经验。"
        elif level == "基本匹配":
            greeting += "\n\n[投递建议] 建议提前研究岗位要求，准备好差距补齐方案。"
        else:
            greeting += "\n\n[投递建议] 可先投递同行业入门级岗位积累经验。"

        return greeting

    @staticmethod
    def format_brief_output(score_result: Dict[str, Any]) -> str:
        """简洁版输出（仅分数+等级）"""
        total = score_result["total_score"]
        level = score_result["match_level"]
        return f"匹配得分：{total}分 | 等级：{level}"
